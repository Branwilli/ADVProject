const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const app = express();

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (if needed)
app.use(express.static('public'));

// API Endpoint to Save Booking Data
app.post('/submit-booking', (req, res) => {
  const newBooking = req.body;

  // Read existing data
  fs.readFile('bookings.json', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error reading booking file.');
    }

    let bookings = JSON.parse(data);

    // Add new booking
    bookings.bookings.push(newBooking);

    // Write updated data back to the file
    fs.writeFile('bookings.json', JSON.stringify(bookings, null, 2), (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error saving booking.');
      }

      res.status(200).send('Booking successfully saved!');
    });
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
