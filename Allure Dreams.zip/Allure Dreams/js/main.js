let users = JSON.parse(localStorage.getItem("users")) || [];  // Ensure fallback to an empty array if not found
let userLogin = JSON.parse(localStorage.getItem("user-login"));
let total = document.getElementById("total-amount");
let buyBtn = document.getElementById("buy");
let isLoggedIn = JSON.parse(localStorage.getItem("loggedIn"));
let ctaBtn = document.querySelector(".cta>a");
let rootPath = window.location.pathname.split("/").slice(0, -1).join("/");
let sidebar = document.querySelector("#sidebar");
let wishlistBtn = document.getElementById("wishlist-btn");  // Assuming you have a wishlist button
let wishlistContainer = document.getElementById("wishlist-container");  // Assuming you have a wishlist container
let wishlistContent = document.getElementById("wishlist-content");

console.log(userLogin);

window.addEventListener("load", function () {
  if (!isLoggedIn) {
    localStorage.setItem("loggedIn", false);
  }
});

function toggleSidebar() {
  sidebar.classList.toggle("show-sidebar");
}

if (isLoggedIn) {
  ctaBtn.innerHTML = `${userLogin.name}  <i class="fa-solid fa-right-from-bracket" style="color: #ffffff;"></i>`;
  ctaBtn.addEventListener("click", () => {
    localStorage.setItem("loggedIn", false);
    localStorage.removeItem("user-login");
    ctaBtn.innerText = "Log In";
    window.location.href = "/";
  });
} else {
  ctaBtn.innerText = "Log In";
  ctaBtn.addEventListener("click", (event) => {
    event.preventDefault();
    window.location.href = "./signup.html";
  });
}

function showPopup() {
  var popup = document.getElementById("popup");
  popup.innerHTML = "Submission Successful";
  popup.style.display = "block";
  setTimeout(function () {
    popup.style.display = "none";
  }, 4000);
}

let checkoutBtn = document.getElementById("checkout");
let buyContent = document.getElementById("buy-content");
let buyContainer = document.getElementById("buy-container");

wishlistBtn.addEventListener("click", function () {
  if (isLoggedIn) {
    populateWishlistContent(userLogin.cart);
  } else {
    populateWishlistContent([]);
  }
  wishlistContainer.classList.toggle("show");
});

function populateWishlistContent(cart) {
  wishlistContent.innerText = "";
  if (isLoggedIn) {
    if (cart.length > 0) {
      let content = document.createElement("div");
      cart.forEach((item, i) => {
        let subText = document.createElement("span");
        subText.classList.add("subtitle");

        // Dynamically set the label based on index
        const labels = ["Name:", "Email:", "Phone Number:", "Address:", "Nationality:", "Country of Origin:", "Price:"];
        subText.innerText = labels[i] || "Price:";

        let row = document.createElement("div");
        row.style.display = "flex";

        // Create and append the Name, Email, Phone Number, Address, etc., to the row
        let nameElem = document.createElement("h3");
        nameElem.innerText = item.name;

        let emailElem = document.createElement("h4");
        emailElem.innerText = item.email || "Not Provided";  // Assuming you have an 'email' property

        let phoneElem = document.createElement("h4");
        phoneElem.innerText = item.phone || "Not Provided";  // Assuming there's a 'phone' property

        let addressElem = document.createElement("h4");
        addressElem.innerText = item.address || "Not Provided";  // Assuming there's an 'address' property

        let nationalityElem = document.createElement("h4");
        nationalityElem.innerText = item.nationality || "Not Provided";  // Assuming there's a 'nationality' property

        let countryElem = document.createElement("h4");
        countryElem.innerText = item.country || "Not Provided";  // Assuming there's a 'country' property

        let priceElem = document.createElement("h4");
        priceElem.innerText = item.updatedPrice ? `$${item.updatedPrice}` : `$${item.price}`;

        let removeBtn = document.createElement("button");
        removeBtn.innerText = "Remove";
        removeBtn.addEventListener("click", () => {
          cart.splice(i, 1);
          userLogin.cart = cart;
          localStorage.setItem("user-login", JSON.stringify(userLogin));
          updateUsers();
          populateWishlistContent(cart);
          displayTotal();
        });

        // Select dropdown for price update
        let selectElement = document.createElement("select");
        let options = ["Yes", "No"];
        options.forEach(option => {
          let optionElement = document.createElement("option");
          optionElement.text = option;
          optionElement.value = option;
          selectElement.appendChild(optionElement);
        });

        // Fix: Correctly set the select element value based on price logic
        selectElement.value = item.updatedPrice / 3 === item.price ? "Yes" : item.updatedPrice / 2 === item.price ? "No" : "Yes";
        
        selectElement.addEventListener("change", () => {
          let v = selectElement.value;
          let updatedPrice;
          if (v === "Yes") {
            updatedPrice = item.price;
          } else if (v === "No") {
            updatedPrice = 3 * item.price;
          }

          cart[i].updatedPrice = updatedPrice;
          priceElem.innerText = `$${updatedPrice}`;
          userLogin.cart = cart;
          localStorage.setItem("user-login", JSON.stringify(userLogin));
          updateUsers();
          displayTotal();
        });

        // Append all these elements to the row
        row.append(nameElem, emailElem, phoneElem, addressElem, nationalityElem, countryElem, priceElem, removeBtn);

        let hr = document.createElement("hr");
        content.append(subText, row, document.createElement("br"), hr);
      });

      displayTotal();
      buyContent.append(content);
      buyBtn.classList.add("show-btn");
      buyBtn.classList.remove("hide-btn");
    } else {
      let emptyMsg = document.createElement("h3");
      emptyMsg.innerText = "Your Cart is empty";
      buyBtn.classList.add("hide-btn");
      buyBtn.classList.remove("show-btn");
      wishlistContent.appendChild(emptyMsg);
    }
  } else {
    buyContent.innerHTML = `<p style="margin-bottom:0.5rem">You are not logged in, please login first</p> <a href='./signup.html' class='primary-btn small'>click here to login</a>`;
    buyBtn.classList.add("hide-btn");
    buyBtn.classList.remove("show-btn");
    document.querySelector("#estimated").style.display = "none";
  }
}

function getTotal() {
  let sum = 0;
  let items = JSON.parse(localStorage.getItem("user-login")).cart || [];
  items.forEach((el) => {
    sum += el.updatedPrice || el.price;
  });
  return sum;
}

function displayTotal() {
  let t = getTotal();
  total.innerHTML = `$${t} <i class="fa-solid fa-money-bill-wave" style="color: #85bb65"></i>`;
}

// Checkout event listener
buyBtn.addEventListener("click", () => {
  updateUsers();
  window.location.href = "/checkout.html";
});

function updateUsers() {
  users.forEach((user) => {
    if (user.email === userLogin.email) {
      user.cart = userLogin.cart;
    }
  });
  localStorage.setItem("users", JSON.stringify(users));
}

// FOR ANIMATION
const sections = document.querySelectorAll(".fade-in");

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting && entry.intersectionRatio >= 0.25) {
        entry.target.classList.add("visible");
      }
    });
  },
  { threshold: 0.25 }
);

sections.forEach((section) => {
  observer.observe(section);
});
