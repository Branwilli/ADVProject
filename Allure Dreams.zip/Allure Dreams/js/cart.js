$(document).ready(function () {
    let cartData = []; // Store all cart items
    let totalPrice = 0;
 
    // Add to Cart Button Handler
    $("#add-to-cart").click(function () {
       const name = $("#name").val();
       const email = $("#email").val();
       const guests = $("#guests").val();
       const service = $("#service").val();
 
       if (!name || !email || !guests || !service) {
          alert("Please fill in all details.");
          return;
       }
 
       // Determine price based on service package
       let price = 0;
       switch (service) {
          case "Basic":
             price = 100;
             break;
          case "Premium":
             price = 200;
             break;
          case "Elite":
             price = 300;
             break;
       }
 
       // Calculate total for the guests
       const itemTotal = price * parseInt(guests);
       totalPrice += itemTotal;
 
       // Add to cartData
       const cartItem = { name, email, guests, service, price, itemTotal };
       cartData.push(cartItem);
 
       // Update cart display
       updateCartDisplay();
    });
 
    // Function to Update Cart Display
    function updateCartDisplay() {
       const cartDetails = $("#cart-details");
       cartDetails.empty(); // Clear previous cart items
 
       cartData.forEach((item, index) => {
          cartDetails.append(`
             <div>
                <p><strong>Item ${index + 1}</strong></p>
                <p>Name: ${item.name}</p>
                <p>Email: ${item.email}</p>
                <p>Guests: ${item.guests}</p>
                <p>Service: ${item.service}</p>
                <p>Price per Guest: $${item.price}</p>
                <p>Item Total: $${item.itemTotal}</p>
             </div>
             <hr>
          `);
       });
 
       // Update Total Price
       $("#total-price").text(`Total Price: $${totalPrice}`);
       $("#cart").show(); // Show cart section
    }
 
    // Make Payment Button Handler
    $("#make-payment").click(function () {
       // Store cart data in sessionStorage
       sessionStorage.setItem("cartData", JSON.stringify(cartData));
       sessionStorage.setItem("totalPrice", totalPrice);
 
       // Redirect to Checkout Page
       window.location.href = "Checkout.html";
    });
 });
 