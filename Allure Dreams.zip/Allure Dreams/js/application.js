let submit = document.createElement("button");
  submit.innerText = "submit";
  addToWishlist.setAttribute("class", "primary-btn");
  addToWishlist.addEventListener("click", () => {
    let obj = {};
    obj["name"] = city.name;
    obj["price"] = city.price;
    if (userLogin.cart.length == 0) {
      userLogin.cart.push(obj);
      localStorage.setItem("user-login", JSON.stringify(userLogin));
      populateWishlistContent(userLogin.cart);
      displayTotal();
    } else {
      let flag = true;
      userLogin.cart.map((el) => {
        if (el.name == city.name) flag = false;
      });
      if (flag) {
        userLogin.cart.push(obj);
        localStorage.setItem("user-login", JSON.stringify(userLogin));
        updateUsers();
        console.log(users);
        populateWishlistContent(userLogin.cart);
        displayTotal();
      }
    }
  });
  