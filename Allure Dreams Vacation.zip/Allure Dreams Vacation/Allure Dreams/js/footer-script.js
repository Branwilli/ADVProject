document.addEventListener('DOMContentLoaded', () => {
    let cartItemCount = 0;

    function updateCartCounter(count) {
        const counterElement = document.getElementById('cart-counter');
        counterElement.textContent = count;
    }

    // Attach click event to all "Book Now" buttons
    const bookNowButtons = document.querySelectorAll('.btn');
    bookNowButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            cartItemCount++;
            updateCartCounter(cartItemCount);

            // Redirect to the booking form
            const bookingFormURL = button.getAttribute('href');
            window.location.href = bookingFormURL;
        });
    });

    // Optional: Fetch cart count from a server (if using backend)
    // fetch('/api/cart/count')
    //    .then(response => response.json())
    //    .then(data => {
    //       cartItemCount = data.count;
    //       updateCartCounter(cartItemCount);
    //    });
});

